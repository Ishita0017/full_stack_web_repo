import React from 'react';
import { useState } from 'react';
import { Button } from '@mui/material';
const SearchPanel =(props)=>{
    const[searchText,setSearchText]=useState('');
    const handleClick=()=>{
        props.searchCallback(searchText)
    }
    const handleSelectChange=()=>{
        alert('select change')
    }

    const handleKeyDown = (e) => {
        //handle Enter key==>keycode =13
        if(e.keyCode === 13){
            props.searchCallback(searchText)
        }
             
        //todo: trigger a search and pass back search text to parent
      
      
    }
    const handleOnChange=(e)=>{
              //update search text state
            setSearchText(e.target.value);
        }
    
    return <>
       
        <div className='searchbar'>

            <input onKeyDown={handleKeyDown}
            onChange={handleOnChange} type="text" 
            placeholder="Search Cryptocurrency"
            value={searchText} />

            <select onChange={handleSelectChange}  >
            <option value="price">Price</option>
            <option value="Market Cap">Market Cap</option>
            <option value="Volume">Volume</option>
            <option value="Change">Change</option> 
            </select>
            <Button onClick={handleClick}>Search</Button>
        </div>
</>
    
}

export default SearchPanel;