import React from 'react';
import SearchPanel from './SearchPanel';
import { useState } from 'react';
import CryptoCard from './CryptoCard';

const Cryptocoins = [{
        name :  "Bitcoin",
        price : "$70821.19558602394",
        volume_24h : "$25033177246.090405",
        percent_change_24h : "-0.20058619%",
        market_cap : "$1395774221617.484",
        Icon:"https://cryptologos.cc/logos/bitcoin-btc-logo.png?v=032"
       },
       {
        name :  "Ethereum" ,
        price : "$3806.4445863590086",
        volume_24h : "$13551493562.865606",
        percent_change_24h : "-1.33186369%",
        market_cap : "$457340754727.2007",
        Icon:"https://cryptologos.cc/logos/ethereum-eth-logo.png?v=032"
       },
       {
        name :  "Tether USDt",
        price : "$0.9996262057964297",
        volume_24h : "$58538261315.54647",
        percent_change_24h : "-0.05458371%",
        market_cap : "$112350050734.07703",
        Icon:"https://cryptologos.cc/logos/tether-usdt-logo.png?v=032"
       },
       {
       
        name :  "BNB" ,
        price : "$707.3071933406279",
        volume_24h : "$3025079413.976436",
        percent_change_24h : "1.15522431%",
        market_cap : "$104373560315.44533",
        Icon:"https://cryptologos.cc/logos/bnb-bnb-logo.png?v=032"
       },
       {
        name :  "Solana" ,
        price : "$170.09348050915858",
        volume_24h : "$1972085706.8931816",
        percent_change_24h : "-1.93944552%",
        market_cap : "$78227877243.55911",
        Icon:"https://cryptologos.cc/logos/solana-sol-logo.png?v=032"
       },
       {
        name :  "USDC" ,
        price : "$0.9999805490149719",
        volume_24h : "$5561814156.204088",
        percent_change_24h : "-0.0051491%",
        market_cap : "$32548433381.675694",
       Icon:"https://cryptologos.cc/logos/usd-coin-usdc-logo.png?v=032"
       },
       {
        name :  "XRP" ,
        price : "$0.5210564739604858",
        volume_24h : "$1194215884.2356727",
        percent_change_24h : "-0.66705127%",
        market_cap : "$28921843184.72782",
        Icon:"https://cryptologos.cc/logos/xrp-xrp-logo.png?v=032"
       },
       {
       
        name :  "Dogecoin" ,
        price : "$0.16035195502575578",
        volume_24h : "$888766631.627938",
        percent_change_24h : "-1.32401658%",
        market_cap : "$23187389207.904922",
        Icon:"https://cryptologos.cc/logos/dogecoin-doge-logo.png?v=032"
       },
       {
       
        name :  "Toncoin" ,
        price : "$7.552038710639501",
        volume_24h : "$309962948.1589212",
        percent_change_24h : "5.52727565%",
        market_cap : "$18352654549.84944",
        Icon:"https://cryptologos.cc/logos/toncoin-ton-logo.png?v=032"
       },
       {
       
        name :  "Cardano" ,
        price : "$0.4603066940584292",
        volume_24h : "$285762407.51125056",
        percent_change_24h : "-0.14156369%",
        market_cap : "$16437942610.681202",
        Icon:"https://cryptologos.cc/logos/cardano-ada-logo.png?v=032"
       },
       {
       
        name :  "Shiba Inu",
        price : "$0.000025172016993436164",
        volume_24h : "$451588451.512004",
        percent_change_24h : "-2.12389515%",
        market_cap : "$14833159474.025286",
        Icon:"https://cryptologos.cc/logos/shiba-inu-shib-logo.png?v=032"
       
       },
       {
        name :  "Avalanche",
        price : "$35.912815799395375",
        volume_24h : "$287450928.9009395",
        percent_change_24h : "-1.60928722%",
        market_cap: "$14122511793.176",
        Icon:"https://cryptologos.cc/logos/avalanche-avax-logo.png?v=032"
        },
       {
       
       
        name :  "Polkadot" ,
        price : "$7.125158960212004",
        volume_24h : "$149944445.16423646",
        percent_change_24h : "-1.55165411%",
        market_cap : "$10245646775.8804",
        Icon:"https://cryptologos.cc/logos/polkadot-new-dot-logo.png?v=032"
       },
       {
       
        name :  "Chainlink" ,
        price : "$17.26704391978826",
        volume_24h : "$412144484.8445809",
        percent_change_24h : "-2.47101789%",
        market_cap : "$10137480975.114658",
        Icon:"https://cryptologos.cc/logos/chainlink-link-logo.png?v=032"
       },
       {
        name :  "TRON" ,
        price : "$0.11472539323558442",
        volume_24h : "$248256933.72971538",
        percent_change_24h : "0.05032222%",
        market_cap : "$10019715736.941511",
        Icon:"https://cryptologos.cc/logos/tron-trx-logo.png?v=032"
       },
       {
        name :  "Bitcoin Cash" ,
        price : "$495.42671231441255",
        volume_24h : "$304902683.1581012",
        percent_change_24h : "-0.021217%",
        market_cap : "$9767792806.570581",
        Icon:"https://cryptologos.cc/logos/bitcoin-cash-bch-logo.png?v=032"
       
       }];


const CryptoDashBoard =()=>{
        const [coinData,setCoinData]= useState(Cryptocoins);

        const handleSearch = (searchText) => {
                if(searchText === ""){
                        alert(`Enter a crypto coin to search`)

                        //reset the full list
                        setCoinData(Cryptocoins);

                        return;
                }

                const filterCoins= Cryptocoins.filter(coin => coin.name.includes(searchText));

                // set state to filter coins and re-render on update

                setCoinData(filterCoins)
        }
return(
    <><div className='app'>
         <h1>Crypto Coin Tracker</h1> 
         <SearchPanel searchCallback={handleSearch}/>
        <div className="crypto-container">
                {
                        coinData.map((currentCoin)=>{
                                return <CryptoCard {...currentCoin} 
                                />
                        })
                }
             
          
    
        </div>
    </div>
</>
);
}
export default CryptoDashBoard;