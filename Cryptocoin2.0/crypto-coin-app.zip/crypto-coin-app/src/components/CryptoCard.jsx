const CryptoCard = (props) => {
    return <>
           <div className="crypto-card">        
                    <img src={props.Icon} alt={props.name}/>
                    <h3>{props.name}</h3>
                    <p>Current Price:{props.price}</p>
                    <p>MarketCap:{props.market_cap}</p>
                    <p>24th Volume:{props.volume_24h}</p>
                    <p>24th Change:{props.percent_change_24h}</p>
                    
            </div>
    </>
}

export default CryptoCard;

