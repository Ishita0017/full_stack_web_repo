import './Styles/SearchBar.css';
import CryptoDashBoard from './components/CryptoDashBoard';
function App() {
  return (
    <div className="App">
     <CryptoDashBoard/>
    </div>
  );
}

export default App;
