import logo from './logo.svg';
import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route,Routes,Navigate, useParams,useNavigate } from 'react-router-dom';
import { useState } from 'react';

function UserProfile(){
  const {userId}=useParams();

  return(
    <div>
      <h2>User Profile</h2>
      <p> User ID:{userId}</p>
    </div>
  );
}
function Dashboard(){
  return<h2>Dashboard</h2>;
}
function Login(){
  return <h2> Login</h2>;
}
function App() {
  const [loggedIn,setLoggedIn]=useState(true);
  
  return (
    <Router>
      <Routes>
        <Route path="/user/:userId" element={<UserProfile/>}/>
        <Route path="/dashboard"
          element={loggedIn?<Dashboard/> : <Navigate replace to={"/login"}/>}
         />
          <Route path="/login" element={<Login/>}/>
          <Route path="/" element={<Navigate replace from="/" to="/dashboard"></Navigate>}/>
        
      </Routes>
    </Router>
   
      
    
  
  );
}

export default App;
