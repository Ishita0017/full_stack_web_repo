import logo from './logo.svg';
import './App.css';
import Counter from './Counter';
import DataFetching from './DataFetching';

function App() {
  return (
    <div className="App">
     <Counter/>
     <DataFetching/>
    </div>
  );
}

export default App;
