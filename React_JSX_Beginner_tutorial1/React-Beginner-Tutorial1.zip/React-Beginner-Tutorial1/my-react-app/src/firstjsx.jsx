const element=<h1>Hello,jsx!</h1>;
const name='John';
const greeting=<p>Hello,{name}!</p>
const link=<a href="https://example.com">Visit Example</a>;

